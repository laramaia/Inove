const senha = document.querySelector('.senha');
    const btn_senha = document.querySelector('#btn_senha');

    btn_senha.onclick = () =>{
        if(senha.type === 'password'){
          senha.type = 'text'
          btn_senha.classList.remove('fa-eye')
            btn_senha.classList.add('fa-eye-slash')
        } else {
            senha.type = 'password'
            btn_senha.classList.remove('fa-eye-slash')
            btn_senha.classList.add('fa-eye')
        }
    }
